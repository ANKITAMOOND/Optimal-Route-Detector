# Hyphen-SCS-Rate-Master-Web-Application-for-
Rate master is a web application which provides rates for different delivery service providers upon inputting initial destination and final destination.
